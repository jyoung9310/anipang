#include "Item.h"

Item::Item(Ani_Pang *a)
{
	this->sample = a;
}