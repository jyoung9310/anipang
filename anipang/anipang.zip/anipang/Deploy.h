#pragma once
#include"Block.h"
#include<ctime>
#include<iostream>
/*
class Deploy {
public:
	void Whole_Deploy(Block AniPang[9][9]);
	void Pang_Deploy();
};
*/

