#include"Pang.h"

Pang::Pang(Ani_Pang *a) {
	this->sample = a;
}

void Pang::rowPang() {
}
void Pang::colPang(){

}
void Pang::itemPang(int row, int col){
	
}

void Pang::PangPang() {
	this->rowPang();
	this->colPang();
}